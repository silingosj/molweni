1. Unzip users package to your localhost (http://127.0.0.1/users).

2. Execute users/usersdb.sql from users package on your database to create users structure. 

3. Run your localhost (http://127.0.0.1/users/index.php). 

4. This applicaion perform simple CRUD and Data Validation for ussers, videos and user_has_videos tables.
We have used the following design patterns PDO, OOP, MVC and Table Data Gateway.

5. Perform simple CRUD for videos table using API.

6. Link and unlink user(s) with videos. 
