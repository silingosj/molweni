-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2020 at 04:45 AM
-- Server version: 8.0.18
-- PHP Version: 7.4.0RC4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `usersdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `filetype`
--

CREATE TABLE `filetype` (
  `id` int(11) NOT NULL,
  `filetype_header` varchar(25) NOT NULL,
  `icon` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `address`, `password`) VALUES
(1, 'John Doe', 0, '', '', ''),
(2, 'Jane Doe', 0, '', '', ''),
(3, 'Rusty Terry', 0, '', '', ''),
(4, 'Peers Sera', 0, '', '', ''),
(5, 'Jaslyn Keely', 0, '', '', ''),
(6, 'Richard Breann', 0, '', '', ''),
(7, 'Imogene Thad', 0, '', '', ''),
(8, 'Tillie Sharalyn', 0, '', '', ''),
(10, 'Coby Kelleigh', 0, '', '', ''),
(11, 'Sarah Sanders', 0, '', '', ''),
(12, 'Elizabeth Stewart', 0, '', '', ''),
(13, 'Hannah Strickland', 0, '', '', ''),
(14, 'Leah Shan', 0, '', '', ''),
(15, 'Beth Skywalker', 0, '', '', ''),
(16, 'Kenneth Sanders', 0, '', '', ''),
(17, 'Joseph Stewart', 0, '', '', ''),
(18, 'Seth Sonnel', 0, '', '', ''),
(19, 'Gareth Solderini', 0, '', '', ''),
(20, 'Darrah Shadow', 0, '', '', ''),
(21, 'Aleksandra Devine', 0, '', '', ''),
(22, 'Thelma Kim', 0, '', '', ''),
(23, 'Myla Bostock', 0, '', '', ''),
(24, 'Abby Wart', 11, 'admin@gmail.com', '1234', ''),
(25, 'Shayan Clements', 0, '', '', ''),
(27, 'Sally Castillo', 0, '', '', ''),
(28, 'Kirstie Thomas', 0, '', '', ''),
(29, 'Maya Paine', 0, '', '', ''),
(30, 'Keziah Knapp', 0, '', '', ''),
(31, 'Junior Douglas', 0, '', '', ''),
(32, 'Kaiden Bentley', 0, '', '', ''),
(33, 'Lawrence Murphy', 0, '', '', ''),
(34, 'Julia Greaves', 0, '', '', ''),
(35, 'Sulaiman Gilmour', 0, '', '', ''),
(36, 'Virgil Collier', 0, '', '', ''),
(37, 'Sacha Gross', 0, '', '', ''),
(38, 'Shannon Peterson', 0, '', '', ''),
(39, 'Joey Whyte', 0, '', '', ''),
(40, 'Jax Howe', 0, '', '', ''),
(41, 'Issac Calderon', 0, '', '', ''),
(42, 'Gregor Bryant', 0, '', '', ''),
(43, 'Aston Simmonds', 0, '', '', ''),
(44, 'Taran Morin', 0, '', '', ''),
(45, 'Issac Calderon', 0, '', '', ''),
(46, 'Gregor Bryant', 0, '', '', ''),
(47, 'Aston Simmonds', 0, '', '', ''),
(48, 'Taran Morin', 0, '', '', ''),
(49, 'Shoaib Vickers', 0, '', '', ''),
(50, 'Nathaniel Khan', 0, '', '', ''),
(51, 'Marcus Best', 0, '', '', ''),
(52, 'Harvey Frame', 0, '', '', ''),
(53, 'Ismaeel Carty', 0, '', '', ''),
(54, 'Rowan Avalos', 0, '', '', ''),
(55, 'Simphiwe James123', 987654321, 'admin@yahoo.com', '098', ''),
(56, 'Sylvia Ngxukuma', 987654321, 'admin@jmail.com', '098', ''),
(57, 'Mthetho Nyaba', 123098567, 'mthetho@gmail.com', '66571231', ''),
(61, 'sasa', 1234567, 'admin1@gmail.com', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `user_has_videos`
--

CREATE TABLE `user_has_videos` (
  `user_id` int(5) NOT NULL,
  `video_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `popularity` float NOT NULL,
  `vote_count` float NOT NULL,
  `video` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `poster_path` blob NOT NULL,
  `id` int(11) NOT NULL,
  `adult` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `backdrop_path` blob NOT NULL,
  `original_language` char(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `original_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `genre_ids` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `vote_average` int(11) NOT NULL,
  `overview` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `release_date` date NOT NULL,
  `poster_path2` blob,
  `backdrop_path2` blob
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `filetype`
--
ALTER TABLE `filetype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `user_has_videos`
--
ALTER TABLE `user_has_videos`
  ADD PRIMARY KEY (`user_id`,`video_id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `filetype`
--
ALTER TABLE `filetype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
