<?php
// MUTE NOTICES
error_reporting(E_ALL & ~E_NOTICE);

// DATABASE SETTINGS - CHANGE TO YOUR OWN !
define('DB_HOST', 'localhost');
define('DB_NAME', 'usersdb');
define('DB_CHARSET', 'utf8');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

/**
 * TMDb configuration
 */
define(
    'TMDB_URL',
    'https://api.themoviedb.org/3/movie/popular?api_key=531eaffcac14a8c431f91d7a77a345e8'
);
// AUTO PATH
define('PATH_LIB', __DIR__ . DIRECTORY_SEPARATOR);
