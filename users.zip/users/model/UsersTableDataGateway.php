<?php

if (!defined('BASE_PATH'))
    define('BASE_PATH', isset($_SERVER['DOCUMENT_ROOT'])
        ? $_SERVER['DOCUMENT_ROOT']
        : substr($_SERVER['PATH_TRANSLATED'], 0, -1 * strlen($_SERVER['SCRIPT_NAME'])));

require_once $_SERVER['DOCUMENT_ROOT'] . '/users/model/Database.php';

class UsersTableDataGateway extends Database
{
    /**
     * Returns all records of users.
     *
     * @param string $order
     * @return array
     */
    public function selectAll($order)
    {
        if (!isset($order)) {
            $order = 'name';
        }

        $pdo = Database::connect();
        $sql = $pdo->prepare('SELECT * FROM users ORDER BY ' . $order . ' ASC');
        $sql->execute();
        $users = array();
        while ($obj = $sql->fetch(PDO::FETCH_OBJ)) {
            $users[] = $obj;
        }
        return $users;
    }

    /**
     * Returns specific user.
     *
     * @param int $id
     * @return mixed
     */
    public function selectById($id)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('SELECT * FROM users WHERE id = ?');
        $sql->bindParam(1, $id, PDO::PARAM_INT);
        $sql->execute();
        $result = $sql->fetch(PDO::FETCH_OBJ);
        return $result;
    }

    /**
     * Add a new user entry.
     *
     * @param string    $name
     * @param int       $phone
     * @param string    $email
     * @param string    $address
     * @param int       $id
     * @param string    $password
     * @return void
     */
    public function insert($name, $phone, $email, $address, $password)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('INSERT INTO users (name, phone, email, address, password) VALUES (?, ?, ?, ?, ?)');
        $sql->bindParam(1, $name, PDO::PARAM_STR);
        $sql->bindParam(2, $phone, PDO::PARAM_INT);
        $sql->bindParam(3, $email, PDO::PARAM_STR);
        $sql->bindParam(4, $address, PDO::PARAM_STR);
        $sql->bindParam(5, $password, PDO::PARAM_STR);
        $sql->execute();
    }

    /**
     * Update a record of user entry.
     *
     * @param string    $name
     * @param int       $phone
     * @param string    $email
     * @param string    $address
     * @param int       $id
     * @return void
     */
    public function edit($name, $phone, $email, $address, $id)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('UPDATE users set name = ?, phone = ?, email = ?, address = ? WHERE id = ? LIMIT 1');
        $sql->bindParam(1, $name, PDO::PARAM_STR);
        $sql->bindParam(2, $phone, PDO::PARAM_INT);
        $sql->bindParam(3, $email, PDO::PARAM_STR);
        $sql->bindParam(4, $address, PDO::PARAM_STR);
        $sql->bindParam(5, $id, PDO::PARAM_INT);
        $sql->execute();
    }

    /**
     * Delete the specific record of user.
     *
     * @param int $id
     * @return void
     */
    public function delete($id)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('DELETE FROM users WHERE id = ?');
        $sql->bindParam(1, $id, PDO::PARAM_INT);
        $sql->execute();
    }

    /**
     * Returns specific record of user. To avoid duplicate username.
     *
     * @param string $email
     * @return mixed
     */
    public function selectByUsername($email)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('SELECT COUNT(*) AS cnt FROM users WHERE email = ?');
        $sql->bindParam(1, $email, PDO::PARAM_STR);
        $sql->execute();
        $result = $sql->fetch(PDO::FETCH_OBJ);
        return $result;
    }

    /**
     * Returns specific record of user. To avoid duplicate phone.
     *
     * @param int $phone
     * @return mixed
     */
    public function selectByPhone($phone)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('SELECT COUNT(*) as cnt FROM users WHERE phone = ?');
        $sql->bindParam(1, $phone, PDO::PARAM_INT);
        $sql->execute();
        $result = $sql->fetch(PDO::FETCH_OBJ);
        return $result;
    }
}
