<?php

if (!defined('BASE_PATH'))
    define('BASE_PATH', empty($_SERVER['DOCUMENT_ROOT'])
        ? $_SERVER['DOCUMENT_ROOT']
        : substr($_SERVER['PATH_TRANSLATED'], 0, -1 * strlen($_SERVER['SCRIPT_NAME'])));

require_once $_SERVER['DOCUMENT_ROOT'] . '/users/model/VideosTableDataGateway.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/users/model/Database.php';

class VideosService extends VideosTableDataGateway
{
    /**
     * Stored video_id in user_videos_link table. 
     * 
     * @var int
     */
    private $videoID = null;

    private $VideosTableDataGateway = null;

    /**
     * The constructor, will automatically connect to the database when the object is created.
     */
    public function __construct()
    {
        $this->videosTableDataGateway = new VideosTableDataGateway();
    }

    /**
     * Returns all videos.
     *
     * @return mixed
     */
    public function getAllVideos()
    {
        try {
            self::connect();
            $result = $this->videosTableDataGateway->selectVidoes();
            self::disconnect();
            return $result;
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }

    /**
     * Returns specific record of video entry.
     *
     * @param int $id
     * @return mixed
     */
    public function getVideo($id)
    {
        try {
            self::connect();
            $result = $this->videosTableDataGateway->selectVideoById($id);
            self::disconnect();
            return $result;
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }

    /**
     * Return response data from requested TMDB API call
     *
     * @param resource $requestURL
     * @return mixed
     */
    public function requestAPI($requestURL)
    {
        $crl = curl_init($requestURL);
        if ($crl == FALSE) {
            return 'Invalid URL: ' . $requestURL;
        }
        curl_setopt($crl, CURLOPT_URL, $requestURL);
        curl_setopt($crl, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);

        $responseURL = curl_exec($crl);

        // get info about the request
        $info = curl_getinfo($crl);

        if (!$responseURL) {
            return 'Error: "' . curl_error($crl) . '" - Code: ' . curl_errno($crl);
        }
        curl_close($crl);

        $data = array();
        $dataJson = json_decode(json_encode($responseURL), true);
        $mixedArrayObjectDirty = json_decode($dataJson);
        $mixedArrayObject = $mixedArrayObjectDirty->results;    //  Return only the required results.

        foreach ($mixedArrayObject as $key => $value) {
            // check for arrays
            if (is_array($value)) { //  TRUE/VALID
                foreach ($value as $k => $v) {
                    $data[$k] = $v;
                }
            } else {    //  FALSE/INVALID
                $data[$key] = $value;
            }
        }

        $pureArray = $this->Object2Array($data);
        foreach ($pureArray as $key => $value) {
            $genre_ids = implode(',', $value['genre_ids']);
            $poster_path = substr($value['poster_path'], 1);
            $backdrop_path = substr($value['backdrop_path'], 1);

            $this->createNewVideo(
                $value['popularity'],
                $value['vote_count'],
                $value['video'],
                // $value['poster_path'],
                $poster_path,
                $value['id'],
                $value['adult'],
                // $value['backdrop_path'],
                $poster_path,
                $value['original_language'],
                $value['original_title'],
                $genre_ids,
                $value['title'],
                $value['vote_average'],
                $value['overview'],
                $value['release_date']
            );
            // file_put_contents(
            //     $_SERVER['DOCUMENT_ROOT'] . '/users/mime_location/' . $poster_path,
            //     $value['title']
            // );
            // file_put_contents(
            //     $_SERVER['DOCUMENT_ROOT'] . '/users/mime_location/' . $backdrop_path,
            //     $value['title']
            // );
        }
    }

    public function Object2Array($obj)
    {
        //only process if it's an object or array being passed to the function
        if (is_object($obj) || is_array($obj)) {
            $ret = (array) $obj;
            foreach ($ret as &$item) {
                //recursively process EACH element regardless of type
                $item = $this->Object2Array($item);
            }
            return $ret;
        }
        //otherwise (i.e. for scalar values) return without modification
        else {
            return $obj;
        }
    }


    /**
     * Add a new record of video entry.
     *
     * @param float     $popularity,
     * @param float     $vote_count,
     * @param string    $video,
     * @param blob      $poster_path,
     * @param int       $id,
     * @param string    $adult,
     * @param blob      $backdrop_path,
     * @param string    $original_language,
     * @param string    $original_title,
     * @param string    $genre_ids,
     * @param string    $title,
     * @param float     $vote_average,
     * @param string    $overview, 
     * @param date      $release_date
     * @return void
     */
    public function createNewVideo($popularity, $vote_count, $video, $poster_path, $id, $adult, $backdrop_path, $original_language, $original_title, $genre_ids, $title, $vote_average, $overview,  $release_date)
    {
        // self::connect();
        // $result = $this->VideosTableDataGateway->selectVideosById($id);
        // self::disconnect();
        // if ($result->cnt === 0) {
        //     do $this->videosTableDataGateway->insertVideo
        // } else {
        //     // $errors[] = 'Video already exists.';
        // }

        try {
            self::connect();
            $result = $this->videosTableDataGateway->insertVideo($popularity, $vote_count, $video, $poster_path, $id, $adult, $backdrop_path, $original_language, $original_title, $genre_ids, $title, $vote_average, $overview,  $release_date);
            $this->videoID = $result->id;
            self::disconnect();
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }

    /**
     * Delete the specified record of video.
     *
     * @param int $id
     * @return void
     */
    public function deleteVideo($id)
    {
        try {
            self::connect();
            $this->videosTableDataGateway->deleteVideo($id);
            self::disconnect();
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }

    /**
     * Add a new record of user with video entry.
     *
     * @param int    $user_id
     * @param int    $video_id
     * @return void
     */
    public function createNewUserWithVideo($user_id, $video_id)
    {
        $video_id = isset($this->videoID) ? $this->videoID : $video_id;
        try {
            self::connect();
            $this->videosTableDataGateway->insertUserWithVideo($user_id, $video_id);
            self::disconnect();
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }

    /**
     * Delete the specified record of user with videos.
     *
     * @param int $user_id
     * @param int $video_id
     * @return void
     */
    public function deleteUserWithVideo($user_id, $video_id)
    {
        try {
            self::connect();
            $this->videosTableDataGateway->deleteUserWithVideo($user_id, $video_id);
            self::disconnect();
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }

    /**
     * Returns specific record of video entry.
     *
     * @param string $field
     * @return mixed
     */
    public function searchVideo($field)
    {
        try {
            self::connect();
            $result = $this->videosTableDataGateway->selectVideoByTitle($field);
            self::disconnect();
            return $result;
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }
}
