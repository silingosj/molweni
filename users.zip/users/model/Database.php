<?php

if (!defined("BASE_PATH"))
  define('BASE_PATH', isset($_SERVER['DOCUMENT_ROOT'])
    ? $_SERVER['DOCUMENT_ROOT']
    : substr($_SERVER['PATH_TRANSLATED'], 0, -1 * strlen($_SERVER['SCRIPT_NAME'])));

require $_SERVER['DOCUMENT_ROOT'] . "/users/config/config.php";

class Database
{

  /**
   * Storeds database object.
   *
   * @var mixed
   */
  private static $conn  = null;

  /**
   * The constructor, will automatically connect to the database when the object is created.
   *
   * @return mixed
   */
  public static function connect()
  {
    if (null == self::$conn) {
      try {
        self::$conn = new PDO(
          "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
          DB_USER,
          DB_PASSWORD,
          [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
          ]
        );
      } catch (PDOException $e) {
        die($e->getMessage());
      }
    }
    return self::$conn;
  }

  /**
   * The destructor, will automatically close the database connection when the object is destroyed.
   *
   * @return mixed
   */
  public static function disconnect()
  {
    self::$conn = null;
  }
}
