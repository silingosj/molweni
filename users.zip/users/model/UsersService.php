<?php

if (!defined('BASE_PATH'))
    define('BASE_PATH', empty($_SERVER['DOCUMENT_ROOT'])
        ? $_SERVER['DOCUMENT_ROOT']
        : substr($_SERVER['PATH_TRANSLATED'], 0, -1 * strlen($_SERVER['SCRIPT_NAME'])));

require_once $_SERVER['DOCUMENT_ROOT'] . '/users/model/UsersTableDataGateway.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/users/model/ValidationException.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/users/model/Database.php';

class UsersService extends UsersTableDataGateway
{
    private $usersTableDataGateway = null;

    /**
     * The constructor, will automatically connect to the database when the object is created.
     */
    public function __construct()
    {
        $this->usersTableDataGateway = new UsersTableDataGateway();
    }

    /**
     * Returns all users.
     *
     * @param mixed $order
     * @return mixed
     */
    public function getAllUsers($order)
    {
        try {
            self::connect();
            $result = $this->usersTableDataGateway->selectAll($order);
            self::disconnect();
            return $result;
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }

    /**
     * Returns specific record of user entry.
     *
     * @param int $id
     * @return mixed
     */
    public function getUser($id)
    {
        try {
            self::connect();
            $result = $this->usersTableDataGateway->selectById($id);
            self::disconnect();
            return $result;
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }

    /**
     * Validate required fields. 
     *
     * @param string    $name
     * @param int       $phone
     * @param string    $email
     * @param string    $address
     * @param string    $password
     * @param string    $password2
     * @param int       $id
     * @return mixed
     */
    private function validateUserParams($name, $phone, $email, $address, $password, $password2, $id = null)
    {
        $errors = array();
        if (empty($id)) {
            if (empty($password)) {
                $errors[] = 'Password field is required.';
            }
            if (empty($password2)) {
                $errors[] = 'Password2 field is required.';
            }
            if ($password !== $password2) {
                $errors[] = 'Your passwords did not match.';
            }
            // if (empty($address)) {
            //     $errors[] = 'Address field is required';
            // }

            self::connect();
            $result = $this->usersTableDataGateway->selectByUsername($email);
            self::disconnect();
            if ($result->cnt > 0) {
                $errors[] = 'Username already exists.';
            }

            self::connect();
            $result = $this->usersTableDataGateway->selectByPhone($phone);
            self::disconnect();
            if ($result->cnt > 0) {
                $errors[] = 'Phone already exists.';
            }
        }

        if (empty($errors)) {
            return;
        }
        throw new ValidationException($errors);
    }

    /**
     * Add a new record of user entry.
     *
     * @param string    $name
     * @param int       $phone
     * @param string    $email
     * @param string    $address
     * @param string    $name
     * @param string    $password
     * @param string    $password2
     * @param int       $id
     * @return void
     */
    public function createNewUser($name, $phone, $email, $address, $password, $password2, $id)
    {
        try {
            self::connect();
            $this->validateUserParams($name, $phone, $email, $address, $password, $password2, $id = null);
            $result = $this->usersTableDataGateway->insert($name, $phone, $email, $address, $password);
            self::disconnect();
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }

    /**
     * Update record entry of user.
     *
     * @param string    $name
     * @param int       $phone
     * @param mixed     $email
     * @param string    $address
     * @param int       $id
     * @return void
     */
    public function editUser($name, $phone, $email, $address, $id)
    {
        try {
            self::connect();
            $this->validateUserParams($name, $phone, $email, $address, null, null, $id);
            $this->usersTableDataGateway->edit($name, $phone, $email, $address, $id);
            self::disconnect();
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }

    /**
     * Delete the specified record of user entry.
     *
     * @param int $id
     * @return void
     */
    public function deleteUser($id)
    {
        try {
            self::connect();
            $this->usersTableDataGateway->delete($id);
            self::disconnect();
        } catch (Exception $e) {
            self::disconnect();
            throw $e;
        }
    }
}
