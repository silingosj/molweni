<?php

if (!defined('BASE_PATH'))
    define('BASE_PATH', isset($_SERVER['DOCUMENT_ROOT'])
        ? $_SERVER['DOCUMENT_ROOT']
        : substr($_SERVER['PATH_TRANSLATED'], 0, -1 * strlen($_SERVER['SCRIPT_NAME'])));

require_once $_SERVER['DOCUMENT_ROOT'] . '/users/model/Database.php';

class VideosTableDataGateway extends Database
{
    /**
     * Returns all records of videos assign to user.
     *
     * @return mixed
     */
    public function selectVidoes()
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('SELECT * FROM videos');
        $sql->execute();
        $videos = array();
        while ($obj = $sql->fetch(PDO::FETCH_OBJ)) {
            $videos[] = $obj;
        }
        return $videos;
    }

    /**
     * Returns specific video details.
     *
     * @param int $id
     * @return mixed
     */
    public function selectVideoById($id)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('SELECT * FROM videos WHERE id = ?');
        $sql->bindParam(1, $id, PDO::PARAM_INT);
        $sql->execute();
        $result = $sql->fetch(PDO::FETCH_OBJ);
        return $result;
    }

    /**
     * Add a new record of video entry.
     *
     * @param float     $popularity,
     * @param float     $vote_count,
     * @param string    $video,
     * @param blob      $poster_path,
     * @param int       $id,
     * @param string    $adult,
     * @param blob      $backdrop_path,
     * @param string    $original_language,
     * @param string    $original_title,
     * @param string    $genre_ids,
     * @param string    $title,
     * @param float     $vote_average,
     * @param string    $overview, 
     * @param date      $release_date
     * @return void
     */
    public function insertVideo($popularity, $vote_count, $video, $poster_path, $id, $adult, $backdrop_path,            $original_language, $original_title, $genre_ids, $title, $vote_average, $overview,  $release_date)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('INSERT INTO videos (`popularity`, `vote_count`, `video`, `poster_path`, `id`, `adult`, `backdrop_path`, `original_language`, `original_title`, `genre_ids`, `title`, `vote_average`, `overview`,  `release_date`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        // $sql->bindParam(1, $id, PDO::PARAM_INT);
        // It is recommended use PDO::bindParam/Value. But limitation of datatype make this very difficult.
        // $sql->execute(array($popularity, $vote_count, $video, $poster_path, $id, $adult, $backdrop_path, $original_language, $original_title, $genre_ids, $title, $vote_average, $overview,  $release_date));
        $sql->bindValue(1, $popularity);
        $sql->bindValue(2, $vote_count);
        $sql->bindValue(3, $video);
        // $sql->bindValue(4, $poster_path);
        $sql->bindValue(4, $poster_path, PDO::PARAM_LOB);
        $sql->bindValue(5, $id);
        $sql->bindValue(6, $adult);
        // $sql->bindValue(7, $backdrop_path);
        $sql->bindValue(7, $backdrop_path, PDO::PARAM_LOB);
        $sql->bindValue(8, $original_language);
        $sql->bindValue(9, $original_title);
        $sql->bindValue(10, $genre_ids);
        $sql->bindValue(11, $title);
        $sql->bindValue(12, $vote_average);
        $sql->bindValue(13, $overview);
        $sql->bindValue(14, $release_date);
        $sql->execute();
    }

    /**
     * Delete the specific record of video.
     *
     * @param int $id
     * @return void
     */
    public function deleteVideo($id)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('DELETE FROM videos WHERE id = ?');
        $sql->bindParam(1, $id, PDO::PARAM_INT);
        $sql->execute();
    }

    /**
     * Add a new record of user with video entry.
     *
     * @param int    $user_id
     * @param int    $video_id
     * @return void
     */
    public function insertUserWithVideo($user_id, $video_id)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('INSERT INTO `user_has_videos` (`user_id`, `video_id`) VALUES (?, ?)');
        $sql->bindParam(1, $user_id, PDO::PARAM_INT);
        $sql->bindParam(2, $video_id, PDO::PARAM_INT);
        $sql->execute();
    }

    /**
     * Delete the specific record of user with video.
     *
     * @param int $user_id
     * @param int $video_id
     * @return void
     */
    public function deleteUserWithVideo($user_id, $video_id)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('DELETE FROM `user_has_videos` WHERE `user_id` = ? and `video_id` = ?');
        $sql->bindParam(1, $user_id, PDO::PARAM_INT);
        $sql->bindParam(2, $video_id, PDO::PARAM_INT);
        $sql->execute();
    }

    /**
     * Returns specific video details.
     *
     * @param string $field
     * @return mixed
     */
    public function selectVideoByTitle($field)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('SELECT * FROM videos WHERE title like ?');
        $sql->bindParam(1, $field, PDO::PARAM_STR);
        $sql->execute();
        $result = $sql->fetch(PDO::FETCH_OBJ);
        return $result;
    }

    /**
     * Returns specific record of video. To avoid duplicate phone.
     *
     * @param int $id
     * @return mixed
     */
    public function selectVideosById($id)
    {
        $pdo = Database::connect();
        $sql = $pdo->prepare('SELECT COUNT(*) as cnt FROM videos WHERE `id` = ?');
        $sql->bindParam(1, $id, PDO::PARAM_INT);
        $sql->execute();
        // $result = $sql->fetch(PDO::FETCH_OBJ);
        $result = $sql->fetch(PDO::FETCH_BOTH);
        return $result;
    }
}
