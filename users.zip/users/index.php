<?php

if (!defined("BASE_PATH"))
    define('BASE_PATH', isset($_SERVER['DOCUMENT_ROOT'])
        ? $_SERVER['DOCUMENT_ROOT']
        : substr($_SERVER['PATH_TRANSLATED'], 0, -1 * strlen($_SERVER['SCRIPT_NAME'])));

require $_SERVER['DOCUMENT_ROOT'] . "/users/controller/UsersController.php";
require $_SERVER['DOCUMENT_ROOT'] . "/users/controller/VideosController.php";

$controller = new UsersController();
// $controllerVideos = new VideosController();

// var_dump($controller);
// die('$controller');

$controller->handleRequest();
