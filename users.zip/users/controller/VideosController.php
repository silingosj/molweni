<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/users/model/Autoloader.php';
require_once ROOT_PATH . '/model/VideosService.php';

class VideosController
{
    /**
     * Controls model proccessing.
     *
     * @var object
     */
    private $videosService = null;

    /**
     * The constructor, will automatically connect to the database when the object is created.
     */
    public function __construct()
    {
        $this->videosService = new VideosService();
    }

    /**
     * Used for redirecting applications menu. 
     *
     * @param mixed $location
     * @return void
     */
    public function redirect($location)
    {
        header('Location: ' . $location);
    }

    /**
     * Used for navigating application operations.
     *
     * @return void
     */
    public function handleRequest()
    {
        $actionvideo = isset($_GET['actionvideo']) ? $_GET['actionvideo'] : null;
        try {
            if ($actionvideo == 'listvideos') {
                $this->listVideos();
            } elseif ($actionvideo == 'addvideo') {
                $this->addVideo();
            } elseif ($actionvideo == 'removevideo') {
                // $this->removeVideo();
            } elseif ($actionvideo == 'showvideo') {
                $this->showVideo();
            } else {
                $this->showError("Page not found", "Page for operation " . $actionvideo . " was not found!");
            }
        } catch (Exception $e) {
            $this->showError("Application error", $e->getMessage());
        }
    }

    /**
     * Displays list of vidoes belonging specific user.
     * 
     * @return mixed
     */
    public function listVideos()
    {
        // $orderby = isset($_GET['orderby']) ? $_GET['orderby'] : null;
        // $users = $this->usersService->getAllVideos($orderby);
        $videos = $this->videosService->getAllVideos();
        include ROOT_PATH . '/view/videos.php';
    }


    /**
     * Add a new record of video to user.
     *
     * @return void
     */
    public function addVideo()
    {
        $title      = 'Add new video';
        $name       = '';
        $phone      = '';
        $email      = '';
        $address    = '';
        $password   = '';
        $password2  = '';
        $id         = '';
        $errors = array();

        if (isset($_POST['form-submitted'])) {

            $name       = isset($_POST['name'])         ? trim($_POST['name'])      : null;
            $phone      = isset($_POST['phone'])        ? trim($_POST['phone'])     : null;
            $email      = isset($_POST['email'])        ? trim($_POST['email'])     : null;
            $address    = isset($_POST['address'])      ? trim($_POST['address'])   : null;
            $password   = isset($_POST['password'])     ? trim($_POST['password'])  : null;
            $password2  = isset($_POST['password2'])    ? trim($_POST['password2']) : null;

            try {
                $this->usersService->createNewUser($name, $phone, $email, $address, $password, $password2, $id = null);
                $this->redirect('index.php');
                return;
            } catch (ValidationException $e) {
                $errors = $e->getErrors();
            }
        }
        include ROOT_PATH . '/view/user-form.php';
    }

    /**
     * Display non-editable detailed record of a video.
     *
     * @return mixed
     */
    public function showVideo()
    {
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        $errors = array();
        if (!$id) {
            throw new Exception('Internal error');
        }
        $user = $this->usersService->getUser($id);
        include ROOT_PATH . 'view/video.php';
    }

    /**
     * Display error message about record of video.
     *
     * @return mixed
     */
    public function showError($title, $message)
    {
        include ROOT_PATH . 'view/error.php';
    }
}
