<?php

require $_SERVER['DOCUMENT_ROOT'] . "/users/config/config.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/users/model/Autoloader.php';
require_once ROOT_PATH . '/model/UsersService.php';
require_once ROOT_PATH . '/model/VideosService.php';

class UsersController
{
    /**
     * Controls model proccessing.
     *
     * @var object
     */
    private $usersService = null;

    /**
     * Controls model proccessing.
     *
     * @var object
     */
    private $videosService = null;

    /**
     * The constructor, will automatically connect to the database when the object is created.
     */
    public function __construct()
    {
        $this->usersService = new UsersService();
        $this->videosService = new VideosService();
    }

    /**
     * Used for redirecting applications menu. 
     *
     * @param mixed $location
     * @return void
     */
    public function redirect($location)
    {
        header('Location: ' . $location);
    }

    /**
     * Used for navigating application operations.
     *
     * @return void
     */
    public function handleRequest()
    {
        $op = isset($_GET['op']) ? $_GET['op'] : null;
        try {
            if (!$op || $op == 'list') {
                $this->listUsers();
            } elseif ($op == 'new') {
                $this->saveUser();
            } elseif ($op == 'edit') {
                $this->editUser();
            } elseif ($op == 'delete') {
                $this->deleteUser();
            } elseif ($op == 'show') {
                $this->showUser();
            } elseif ($op == 'listvideos') {
                $this->listVideos();
            } elseif ($op == 'newvideos') {
                $this->saveVideos();
            } elseif ($op == 'showvideo') {
                $this->showVideo();
            } elseif ($op == 'searchvideo') {
                $this->searchVideo();
            } else {
                $this->showError("Page not found", "Page for operation " . $op . " was not found!");
            }
        } catch (Exception $e) {
            $this->showError("Application error", $e->getMessage());
        }
    }

    /**
     * Returns all users.
     * 
     * @return array
     */
    public function listUsers()
    {
        $orderby = isset($_GET['orderby']) ? $_GET['orderby'] : null;
        $users = $this->usersService->getAllUsers($orderby);
        include ROOT_PATH . '/view/users.php';
    }

    /**
     * Add a new record of user entry.
     *
     * @return void
     */
    public function saveUser()
    {
        $title      = 'Add new user';
        $name       = '';
        $phone      = '';
        $email      = '';
        $address    = '';
        $password   = '';
        $password2  = '';
        $id         = '';
        $errors = array();

        if (isset($_POST['form-submitted'])) {

            $name       = isset($_POST['name'])         ? trim($_POST['name'])      : null;
            $phone      = isset($_POST['phone'])        ? trim($_POST['phone'])     : null;
            $email      = isset($_POST['email'])        ? trim($_POST['email'])     : null;
            $address    = isset($_POST['address'])      ? trim($_POST['address'])   : null;
            $password   = isset($_POST['password'])     ? trim($_POST['password'])  : null;
            $password2  = isset($_POST['password2'])    ? trim($_POST['password2']) : null;

            try {
                $this->usersService->createNewUser($name, $phone, $email, $address, $password, $password2, $id = null);
                $this->redirect('index.php');
                return;
            } catch (ValidationException $e) {
                $errors = $e->getErrors();
            }
        }
        include ROOT_PATH . '/view/user-form.php';
    }

    /**
     * Update a record of user entry.
     *
     * @return mixed
     */
    public function editUser()
    {
        $title      = "Edit User";
        $name       = '';
        $phone      = '';
        $email      = '';
        $address    = '';
        $id         = $_GET['id'];
        $errors     = array();
        $user       = $this->usersService->getUser($id);

        if (isset($_POST['form-submitted'])) {

            $name    = isset($_POST['name'])    ? trim($_POST['name'])    : null;
            $phone   = isset($_POST['phone'])   ? trim($_POST['phone'])   : null;
            $email   = isset($_POST['email'])   ? trim($_POST['email'])   : null;
            $address = isset($_POST['address']) ? trim($_POST['address']) : null;

            try {
                $this->usersService->editUser($name, $phone, $email, $address, $id);
                $this->redirect('index.php');
                return;
            } catch (ValidationException $e) {
                $errors = $e->getErrors();
            }
        }
        include ROOT_PATH . 'view/user-form-edit.php';
    }

    /**
     * Delete the specific record entry of user.
     *
     * @return mixed
     */
    public function deleteUser()
    {
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        if (!$id) {
            throw new Exception('Internal error');
        }
        $this->usersService->deleteUser($id);
        $this->redirect('index.php');
    }

    /**
     * Display non-editable record of user.
     *
     * @return mixed
     */
    public function showUser()
    {
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        $errors = array();
        if (!$id) {
            throw new Exception('Internal error');
        }
        $user = $this->usersService->getUser($id);
        include ROOT_PATH . 'view/user.php';
    }


    /**
     * Display error message about record of user.
     *
     * @return mixed
     */
    public function showError($title, $message)
    {
        include ROOT_PATH . 'view/error.php';
    }

    /**
     * Displays list of vidoes linked to specific user.
     * 
     * @return mixed
     */
    public function listVideos()
    {
        try {
            $videos = $this->videosService->getAllVideos();
        } catch (ValidationException $e) {
            $errors = $e->getErrors();
        }
        include ROOT_PATH . '/view/videos.php';
    }

    /**
     * Displays list of vidoes linked to specific user.
     * 
     * @return mixed
     */
    public function saveVideos()
    {
        try {
            $this->videosService->requestAPI(TMDB_URL);
            $this->listVideos();
        } catch (ValidationException $e) {
            $errors = $e->getErrors();
        }
    }

    /**
     * Display non-editable record of video.
     *
     * @return mixed
     */
    public function showVideo()
    {
        $videoid = isset($_GET['videoid']) ? $_GET['videoid'] : null;
        $errors = array();
        if (!$videoid) {
            throw new Exception('Internal error');
        }
        $video = $this->videosService->getVideo($videoid);
        include ROOT_PATH . 'view/video.php';
    }

    /**
     * Search video.
     *
     * @return mixed
     */
    public function searchVideo()
    {
        if (isset($_GET['searchvideo'])) {

            $videofield = isset($_GET['videofield']) ? $_GET['videofield'] : null;
            $errors = array();
            if (!$videofield) {
                throw new Exception('Internal error');
            }
            $video = $this->videosService->getVideo($videofield);
            include ROOT_PATH . 'view/videos.php';
        }
    }
}
