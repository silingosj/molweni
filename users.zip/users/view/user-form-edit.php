<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>
        <?php echo htmlentities($title); ?>
    </title>
</head>

<body>
    <h3>Edit User</h3>
    <?php
    if ($errors) {
        echo '<ul>';
        foreach ($errors as $field => $error) {
            echo '<li style="color: red;">' . htmlentities($error) . '</li>';
        }
        echo '</ul>';
    }
    ?>

    <form method="post" action="">
        <label for="Email">Email: </label><br>
        <input type="text" name="email" value="<?php echo htmlentities($user->email); ?>" required><span style="color: red;">*</span><br>
        <label for="phone">Phone: </label><br>
        <input type="text" name="phone" value="<?php echo htmlentities($user->phone); ?>" required><span style="color: red;">*</span>
        <br>
        <label for="name">Name: </label><br>
        <input type="text" name="name" value="<?php echo htmlentities($user->name); ?>" required><span style="color: red;">*</span><br>
        <label for="Address">Address: </label><br>
        <textarea name="address"><?php echo htmlentities($user->address); ?></textarea>
        <br>
        <input type="hidden" name="form-submitted" value="1">
        <input type="submit" value="Edit">
        <button type="button" onclick="location.href='index.php'">Cancel</button>
    </form>
</body>

</html>