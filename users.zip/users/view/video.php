<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title><?php echo $video->title; ?></title>
</head>

<body>
    <h1><?php echo $video->title; ?></h1>

    <div>
        <span class="label">Movie:</span>

        <?php $filepath = $_SERVER['DOCUMENT_ROOT'] . '/users/mime_location/' . (array) $video->poster_path;
        echo '<img src=' . $filepath . ' />' ?>
    </div>

    <div>
        <span class="label">Popularity:</span>
        <?php echo $video->popurality; ?>
    </div>
    <div>
        <span class="label">Vote Count:</span>
        <?php echo $video->vote_count; ?>
    </div>
    <div>
        <span class="label">Vote Average:</span>
        <?php echo $video->vote_average; ?>
    </div>
    <div>
        <span class="label">Overview:</span>
        <?php echo $video->overview; ?>
    </div>
</body>

</html>