<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8ll0000">
</head>

<body>
    <h3>Add New User</h3>
    <?php
    if ($errors) {
        echo '<ul>';
        foreach ($errors as $field => $error) {
            echo '<li style="color: red;">' . htmlentities($error) . '</li>';
        }
        echo '</ul>';
    }
    ?>

    <form method="post" action="">
        <label for="Email">Email: </label><br>
        <input type="text" name="email" value="<?php echo htmlentities($email); ?>" required><span style="color: red;">*</span><br>
        <label for="password">Password: </label><br>
        <input type="password" name="password" value="<?php echo htmlentities($password); ?>" required><span style="color: red;">*</span><br>
        <label for="password2">Password2: </label><br>
        <input type="password" name="password2" value="<?php echo htmlentities($password2); ?>" required><span style="color: red;">*</span><br>
        <label for="phone">Phone: </label><br>
        <input type="text" name="phone" value="<?php echo htmlentities($phone); ?>" required><span style="color: red;">*</span><br>
        <label for="name">Name: </label><br>
        <input type="text" name="name" value="<?php echo htmlentities($name); ?>"><span style="color: red;">*</span><br>
        <label for="Address">Address: </label><br>
        <textarea name="address"><?php echo htmlentities($address); ?></textarea><br>
        <input type="hidden" name="form-submitted" value="1">
        <input type="submit" value="Submit">
        <button type="button" onclick="location.href='index.php'">Cancel</button>
    </form>
</body>

</html>