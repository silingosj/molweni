<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Videos</title>
    <style type="text/css">
        table.videos {
            width: 100%;
        }

        table.videos thead {
            background-color: #eee;
            text-align: left;

        }

        table.videos thead th {
            border: solid 1px #fff;
            padding: 3px;
        }

        table.videos tbody td {
            border: solid 1px #eee;
            padding: 3px;
        }

        a,
        a:hover,
        a:active,
        a:visited {
            color: blue;
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <h3>VIDEOS</h3>
    <?php
    if ($errors) {
        echo '<ul>';
        foreach ($errors as $field => $error) {
            echo '<li style="color: red;">' . htmlentities($error) . '</li>';
        }
        echo '</ul>';
    }
    ?>

    <div><a href="index.php">Go to Users</a></div><br>
    <div><a href="index.php?op=newvideos">Download Videos from TMDB API</a></div><br>
    <!-- <div>
        <inpt type="text" name="videofield" value=""><input type='button' name='searchvideo' value='Search Video'>
    </div><br> -->
    <!--<div><a href="index.php?op=removevideos">Remove Videos</a></div><br> -->
    <table class="videos" cellpadding="0" cellspacing="0">
        <thead>
            <tr>
                <th>Title</th>
                <th>Popurality</th>
                <th>Vote Count</th>
                <th>Vote Average</th>
                <th>Add</th>
                <th>Remove</th>
                <th>Overview</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($videos as $video) : ?>
                <tr>
                    <td><a href="index.php?op=showvideo&videoid=<?php echo $video->id; ?>"><?php echo htmlentities($video->title); ?></a></td>
                    <td><?php echo htmlentities($video->popularity); ?></td>
                    <td><?php echo htmlentities($video->vote_count); ?></td>
                    <td><?php echo htmlentities($video->vote_average); ?></td>
                    <td><a href="index.php?op=addvideo&videoid=<?php echo $video->id; ?>">Add</a></td>
                    <td><a href="index.php?op=remove&videoid=<?php echo $video->id; ?>" onclick="return confirm('Are you sure you want to delete?');">Remove</a></td>
                    <td><?php echo htmlentities($video->overview); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>