<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title><?php echo $user->name; ?></title>
</head>

<body>
    <h1><?php echo $user->name; ?></h1>
    <div>
        <span class="label">Phone:</span>
        <?php echo $user->phone; ?>
    </div>
    <div>
        <span class="label">Email:</span>
        <?php echo $user->email; ?>
    </div>
    <div>
        <span class="label">Address:</span>
        <?php echo $user->address; ?>
    </div>
</body>

</html>